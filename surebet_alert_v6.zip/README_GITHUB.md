# Surebet Alert v6 — GitHub 24/7

## Co robi

Workflow GitHub Actions uruchamia skaner co około 5 minut, wyszukuje ścisłe arbitraże w publicznie prezentowanych kursach, potwierdza kandydatów i wysyła nowe okazje na Telegram. Panel jest publikowany przez GitHub Pages.

### Ważne

- Skanowanie jest cykliczne, nie sekundowe. GitHub podaje minimalny interwał harmonogramu 5 minut.
- Harmonogram może być opóźniony przez GitHub.
- Repozytorium powinno być publiczne, aby standardowe runnery były bezpłatne i nielimitowane.
- Nie umieszczaj tokena Telegrama w plikach repozytorium.

## Konfiguracja

1. Utwórz publiczne repozytorium GitHub.
2. Wgraj **zawartość tego folderu** do gałęzi `main`.
3. Wejdź w `Settings → Secrets and variables → Actions` i utwórz:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
4. Wejdź w `Settings → Pages` i wybierz `GitHub Actions` jako źródło publikacji.
5. Wejdź w `Actions → Surebet Scanner` i kliknij `Run workflow`.
6. Po ukończeniu runu wejście do `Settings → Pages` pokaże adres panelu.

## Telegram

Utwórz bota przez `@BotFather`, rozpocznij rozmowę z botem i wyślij dowolną wiadomość. Następnie użyj Telegram Bot API `getUpdates`, aby znaleźć identyfikator czatu (`chat.id`).

## Dane kursowe

Skaner korzysta z publicznie prezentowanych danych DobryBuk. Kursy należy zawsze sprawdzić bezpośrednio u bukmachera przed zawarciem obu zakładów; publiczna porównywarka może mieć opóźnienie lub nie odzwierciedlać warunków konkretnego konta.
