@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "LOG=%CD%\startup.log"
>"%LOG%" echo ==== Surebet Alert startup %date% %time% ====

call :find_python
if not defined PYEXE goto :install_python

goto :python_found

:install_python
echo.
echo Nie znaleziono Pythona. Probuje zainstalowac go automatycznie...
echo Nie znaleziono Pythona. Probuje zainstalowac go automatycznie...>>"%LOG%"

where winget >nul 2>&1
if not errorlevel 1 (
  echo Instalowanie Python przez winget...
  winget install --id Python.Python.3.13 -e --scope user --accept-source-agreements --accept-package-agreements >>"%LOG%" 2>&1
  call :find_python
  if defined PYEXE goto :python_found
)

echo Pobieranie oficjalnego instalatora Python 3.13.16...
set "PY_URL=https://www.python.org/ftp/python/3.13.16/python-3.13.16-amd64.exe"
set "PY_INSTALLER=%TEMP%\python-3.13.16-amd64.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_INSTALLER%' -UseBasicParsing" >>"%LOG%" 2>&1
if errorlevel 1 goto :install_failed
if not exist "%PY_INSTALLER%" goto :install_failed
"%PY_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0 SimpleInstall=1 >>"%LOG%" 2>&1
if errorlevel 1 goto :install_failed
del /q "%PY_INSTALLER%" >nul 2>&1
call :find_python
if not defined PYEXE goto :install_failed

goto :python_found

:python_found
echo.
echo Znaleziono Python: %PYEXE%
echo Znaleziono Python: %PYEXE%>>"%LOG%"
"%PYEXE%" %PYARGS% --version >>"%LOG%" 2>&1
if errorlevel 1 goto :python_failed

if not exist ".venv\Scripts\python.exe" (
  echo [1/4] Tworzenie srodowiska Python...
  "%PYEXE%" %PYARGS% -m venv ".venv" >>"%LOG%" 2>&1
  if errorlevel 1 goto :venv_failed
)
set "VENV_PY=%CD%\.venv\Scripts\python.exe"
if not exist "%VENV_PY%" goto :venv_failed

echo [2/4] Instalowanie bibliotek...
"%VENV_PY%" -m pip install --disable-pip-version-check --upgrade pip >>"%LOG%" 2>&1
if errorlevel 1 goto :pip_failed
"%VENV_PY%" -m pip install --disable-pip-version-check -r requirements.txt >>"%LOG%" 2>&1
if errorlevel 1 goto :pip_failed

echo [3/4] Instalowanie Chromium...
"%VENV_PY%" -m playwright install chromium >>"%LOG%" 2>&1
if errorlevel 1 goto :playwright_failed

if not exist ".env" copy /y ".env.example" ".env" >nul

echo [4/4] Uruchamianie aplikacji...
echo.
echo ========================================
echo PANEL: http://127.0.0.1:8080
echo ========================================
echo.
echo Panel otworzy sie automatycznie.
echo NIE naciskaj Ctrl+C i nie zamykaj tego okna, gdy chcesz aby skaner dzialal.
echo Aby zatrzymac program, zamknij to okno lub uzyj Ctrl+C.
eecho Panel: http://127.0.0.1:8080>>"%LOG%"

start "" /b powershell -NoProfile -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:8080'"
"%VENV_PY%" -m app.main >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
echo.>>"%LOG%"
echo ==== Proces zakonczyl sie kodem %RC% %date% %time% ====>>"%LOG%"
if not "%RC%"=="0" (
  echo Aplikacja zakonczyla sie bledem. Otwieram startup.log...
  notepad "%LOG%"
)
pause
exit /b %RC%

:find_python
set "PYEXE="
set "PYARGS="

for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
if defined PYEXE (
  "%PYEXE%" --version >nul 2>&1
  if not errorlevel 1 exit /b 0
  set "PYEXE="
)

for /f "delims=" %%P in ('powershell -NoProfile -Command "$roots=@($env:LocalAppData+'\\Programs\\Python',$env:ProgramFiles,$env:ProgramW6432); $files=@(); foreach($r in $roots){if(Test-Path $r){$files += Get-ChildItem -Path $r -Filter python.exe -Recurse -ErrorAction SilentlyContinue}}; $files | Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName" 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
if defined PYEXE (
  "%PYEXE%" --version >nul 2>&1
  if not errorlevel 1 exit /b 0
  set "PYEXE="
)

for /f "delims=" %%P in ('where py 2^>nul') do if not defined PYEXE (
  set "PYEXE=%%P"
  set "PYARGS=-3"
)
if defined PYEXE (
  "%PYEXE%" %PYARGS% --version >nul 2>&1
  if not errorlevel 1 exit /b 0
  set "PYEXE="
  set "PYARGS="
)
exit /b 1

:python_failed
echo.
echo Python zostal znaleziony, ale nie mozna go uruchomic.
echo Szczegoly: %LOG%
notepad "%LOG%"
pause
exit /b 1

:install_failed
echo.
echo Nie udalo sie znalezc/zainstalowac Pythona.
echo Szczegoly sa w: %LOG%
start "" "https://www.python.org/downloads/windows/"
notepad "%LOG%"
pause
exit /b 1

:venv_failed
echo.
echo Nie udalo sie utworzyc srodowiska Python. Szczegoly: %LOG%
notepad "%LOG%"
pause
exit /b 1

:pip_failed
echo.
echo Nie udalo sie zainstalowac bibliotek. Szczegoly: %LOG%
notepad "%LOG%"
pause
exit /b 1

:playwright_failed
echo.
echo Nie udalo sie zainstalowac Chromium. Szczegoly: %LOG%
notepad "%LOG%"
pause
exit /b 1
