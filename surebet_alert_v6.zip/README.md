# Surebet Alert v6

Ciemny panel do monitorowania publicznie prezentowanych kursów i wykrywania **ścisłych arbitraży (surebetów)**. Aplikacja nie składa automatycznie zakładów.

## GitHub Actions + Telegram

Ta wersja jest przygotowana do pracy bez włączonego PC. GitHub Actions uruchamia skan co około 5 minut, a Telegram dostaje alert, kiedy zostanie znaleziony i potwierdzony nowy surebet. GitHub podaje, że najkrótszy interwał dla `schedule` to 5 minut. W publicznych repozytoriach standardowe runnery są bezpłatne i bez limitu minut. Harmonogramy mogą jednak być opóźnione, a w publicznym repozytorium workflow bez aktywności może zostać automatycznie wyłączony po 60 dniach.

### 1. Załóż repozytorium na GitHub
Najprościej utwórz **publiczne** repozytorium, np. `surebet-alert`.

### 2. Wgraj zawartość tego folderu
W repozytorium mają znaleźć się m.in. `.github/workflows/surebet.yml`, `app/`, `docs/`, `scanner_github.py`, `requirements.txt`.

### 3. Dodaj sekrety Telegrama
GitHub → **Settings → Secrets and variables → Actions → New repository secret**.

Dodaj:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Tokenu nie wpisuj do plików repozytorium.

### 4. Włącz GitHub Pages
GitHub → **Settings → Pages** → jako źródło wybierz **GitHub Actions**.

Po pierwszym uruchomieniu workflow strona zostanie opublikowana.

### 5. Uruchom skaner ręcznie pierwszy raz
GitHub → **Actions → Surebet Scanner → Run workflow**.

Po wykonaniu zobaczysz najnowsze dane na stronie, a przy znalezieniu nowego surebeta bot wyśle Telegram.

## Kalkulator

Dashboard ma jeden wspólny budżet. Zmieniasz np. `50` → `100` → `250` zł, a wszystkie znalezione okazje są przeliczane **od razu**, bez przycisku „Oblicz”. Każdy surebet pokazuje osobno stawki, kursy, bukmacherów oraz przycisk przejścia do źródła/bukmachera.

## Monitoring

Domyślnie filtrujemy tylko ścisłe rynki 2-drogowe oraz 1X2, aby ograniczyć fałszywe arbitraże. Dodatkowe typy rynków można dodać później.

Kursy z publicznej porównywarki mogą różnić się od kursów widocznych bezpośrednio u bukmachera. Przed zawarciem obu zakładów sprawdź oba kursy i zasady rozliczenia. Podatek/promocje mogą zmieniać rzeczywistą wypłatę.

## Windows

Możesz też użyć `start_windows.bat` i mieć lokalny panel. Wtedy skaner działa tylko, gdy aplikacja jest uruchomiona na komputerze.

## Źródło kursów

Skaner używa publicznie prezentowanych danych porównywarki DobryBuk. To rozwiązanie nie wymaga płatnego klucza do agregatora, ale jest bardziej podatne na zmiany strony źródłowej niż dedykowane API.
